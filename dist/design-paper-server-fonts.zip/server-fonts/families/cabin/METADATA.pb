name: "Cabin"
designer: "Impallari Type, Rodrigo Fuenzalida"
license: "OFL"
category: "SANS_SERIF"
date_added: "2020-07-22"
fonts {
  name: "Cabin"
  style: "normal"
  weight: 400
  filename: "Cabin[wdth,wght].ttf"
  post_script_name: "Cabin-Regular"
  full_name: "Cabin Regular"
  copyright: "Copyright 2018 The Cabin Project Authors (https://github.com/impallari/Cabin)"
}
fonts {
  name: "Cabin"
  style: "italic"
  weight: 400
  filename: "Cabin-Italic[wdth,wght].ttf"
  post_script_name: "Cabin-Italic"
  full_name: "Cabin Italic"
  copyright: "Copyright 2018 The Cabin Project Authors (https://github.com/impallari/Cabin)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wdth"
  min_value: 75.0
  max_value: 100.0
}
axes {
  tag: "wght"
  min_value: 400.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/impallari/Cabin"
  commit: "70efa8c3179359cc50b01ca184fec8a694156140"
}
