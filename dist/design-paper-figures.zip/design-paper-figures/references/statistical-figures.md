# Statistical figures

Use these rules for line, bar, scatter, bubble, distribution, uncertainty, scaling, correlation, heatmap, table, and multi-panel statistical figures.

## Start from a stable visual skeleton

- Use a white or venue-compatible background and a single coherent font family.
- Strongly prefer a complete four-sided frame for ordinary academic axes. Start near `0.8 pt` for all spines, then inspect at final size.
- Use shallow gray grid lines only when they help estimate values. Start with `#D3D3D3`, `0.5 pt`, below all data. Disable the grid deliberately when it adds no information.
- Keep ticks, labels, legends, and panels consistent. Do not bold every label; reserve bold for the proposed method, a short panel conclusion, or the leading caption sentence.
- Avoid the default Matplotlib color cycle and pure RGB primaries for data series.

## Choose typography deliberately

- Read `typography.md` and select a named font profile before drawing. Do not treat Arial as the aesthetic default merely because it is common.
- Start with the `preferred`/`optima` profile when Optima is installed and exportable. Consider `futura` for compact plots with short labels, and `gill-sans` for a distinctive but more forgiving humanist alternative.
- Use `helvetica-neue`, `avenir`, or `seaborn` when a more neutral voice is appropriate. Reserve `conservative` Arial for explicit user preference, venue compatibility, or fallback after preferred choices fail.
- Do not confuse the Seaborn visual theme with a proprietary Seaborn font. In a standard Matplotlib installation, Seaborn usually inherits DejaVu Sans unless the environment overrides it.
- Compare fonts at the same physical paper size. Equal point sizes do not have equal apparent size: re-check tick density, legend width, capitalization, and label padding after changing the family.

## Choose scale and ticks by meaning

- Use a linear axis when absolute differences matter.
- Consider a log axis when values span about an order of magnitude or when multiplicative change is the scientific relationship. Do not apply it to zero/negative values without a justified transformation.
- Set meaningful major ticks explicitly. Large-range examples may use irregular displayed values such as `1.2, 1.5, 2, 3, 5, 10, 20, 30` on a log scale.
- For compute, FLOPs, parameters, or throughput, show only a few narrative major ticks and retain small unlabeled minor ticks when useful.
- Do not let automatic scientific notation or excessive tick density dictate the story.

## Use color, lightness, and alpha for different jobs

- Use different hues for independent model families or categories.
- Use fixed light/mid/deep RGB colors within a hue for size, scale, or stage. This is more stable than simulating every light color with transparency.
- Use alpha for confidence bands, background regimes, overlapping bubbles, shadows, or locator lines.
- Start background regimes around `alpha=0.10–0.18`; overlapping bubbles around `0.75`; locator lines around `0.5`. Adjust against the actual background.
- Keep baselines neutral and the proposed method on a stronger anchor color. Add markers, line styles, or direct labels so color is not the only discriminator.
- Use `references/color-system.md` and `assets/color-bank.json`; do not assemble an untested rainbow from unrelated combinations.

## Draw background regions without hiding the plot

1. Draw the grid below the data.
2. Reuse the related semantic color at low alpha for the region.
3. Draw curves, points, boundaries, and annotations above it.
4. Confirm the grid and small markers remain visible after PDF export.
5. Keep local annotation boxes more opaque than background regimes and give them a related darker border.

## Build a zoomed inset as one component

Use a zoomed inset only when a scientifically important local difference is otherwise unreadable.

1. Mark the exact region of interest on the main axes.
2. Connect it to the inset with one or two low-opacity locator lines.
3. Give the inset independent limits, fewer ticks, and slightly smaller labels.
4. Keep its frame compatible with the main axes; do not automatically make it heavy.
5. Test candidate corners against the legend, peaks, annotations, and dense curves. If no internal corner is safe, place the inset outside or redesign the panels.

Useful starting points are an inset occupying roughly `30–45%` of the main axes width/height, a `0.8 pt` inset frame, and `1.0 pt`, `alpha≈0.5` ROI/connector lines. Adapt them to the data.

Do not confuse this component with an image magnification patch. Statistical insets have their own axes and ticks; image patches preserve pixel correspondence.

## Use annotations economically

- Put one or two short summaries inside a stable empty area rather than creating a new caption row. Use axes-relative coordinates and the same anchor across related panels.
- Move long prose, numerous labels, or inconsistent panel summaries outside the axes.
- Prefer direct labels when they reduce legend lookup and do not collide with data.
- Use a small opaque or translucent backing only when the local background makes text unreliable.

## Allocate multi-panel space by information density

- Do not default to equal columns. A wide training curve beside a compact correlation summary may justify a width ratio near `2.3:1`.
- Reduce repeated tick labels and redundant legends. Preserve shared baselines and row/column alignment.
- Keep row/column gaps small but nonzero when needed for labels. Compactness is high information use, not the absence of spacing.
- Put small correlation or summary labels inside the panel when they fit cleanly; do not spend a full external row for one short value.

## Style tables consistently

- Use a very light neutral gray such as `#E6E6E6` to mark a default, selected, or reference configuration.
- Use bold separately to indicate best numerical performance. Do not make background color and bold carry the same meaning.
- Keep rules and padding restrained. Align decimals and comparable units.

## Export and inspect

- Save PDF or SVG as the primary output and PNG at `300 dpi` or higher as a preview.
- Embed fonts where possible; for Matplotlib prefer PDF font type 42 and live SVG text.
- Render the vector file back to pixels at the intended paper width and check clipping, font substitution, overly fine lines, legend/inset conflicts, and gray-scale readability.
- Retain the plotting source and deterministic input data or data-loading path.

## Checklist

- Scale and manual ticks match the scientific relationship.
- Four-sided frame, grid decision, and line widths were inspected at final size.
- Palette is coherent; baselines and hierarchy are clear without color alone.
- Alpha is used only for overlap/background/uncertainty, not as a substitute for every light color.
- Insets include ROI, connectors, sparse ticks, and occlusion checks.
- Panel proportions, internal annotations, and gaps follow information density.
- Vector and PNG outputs were both visually verified.
