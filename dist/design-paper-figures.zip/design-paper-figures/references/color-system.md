# Global color system

Use this color system across statistical plots, pipelines, architecture diagrams, teasers, result displays, tables, and callouts. The colors were selected from research-paper references, including Graphics/SIGGRAPH papers, but are not venue- or task-specific.

Exact records, roles, alpha values, provenance, and combination membership live in `../assets/color-bank.json`. View `../assets/master-color-bank-palette.svg` for the complete swatch sheet.

## Select a combination, not isolated favorite colors

1. Identify the relationship: multiple categories, binary comparison, status regions, semantic flows, previous/ours, continuous signed field, sequential intensity, or a small coordinated trio.
2. Choose one main combination from the table below.
3. Use only the smallest subset needed.
4. Bind each color to a stable semantic role across boxes, arrows, labels, markers, and legends.
5. Use shared neutrals for most structure.
6. Add a color outside the bank only when the existing combinations cannot satisfy category count, contrast, accessibility, or an explicit user/venue constraint.

Do not take one attractive color from several unrelated combinations and call the result a palette. A color may appear in multiple combinations; choose the membership whose roles match the figure.

## Curated combinations

| ID | Relationship and colors | Status / guidance |
|---|---|---|
| P1 | Soft scientific five-hue: orange `#F9CB8A #F7BA64 #F5A83D`; coral `#FBA09D #F86762 #F5433D`; grass `#B3CDA2 #9EBF88 #88B06D`; purple `#D0B3FF #A984E6 #7A5DE1`; blue `#AEC6FE #86AAFE #5D8DFD`; baseline `#BFBFC5 #D4D4D8` | Preferred. Hue = category; light→deep = scale/stage. |
| P2 | Warm coral `#FB8E89`, cool blue `#6F9AFE`, structure gray `#595959` | Approved binary comparison. Do not treat near-P1 corals as separate categories. |
| P3 | Status set: red `#F5433D`, green `#88B06D`, blue `#5D8DFD`; warm callout `#EF9463` at `α.60` + `#C46032`; cool callout `#002FAB` at `α.30` + `#496EC8`; grid `#D3D3D3` | Validated for regime maps and local callouts. |
| P4 | Deep semantic flow `#B1001C #003776 #310067 #907CBB`; card extensions `#92BFFF↔#0C2734`, `#939595↔#DADADA`, `#FFFFFF↔#DADADA`, `#901113↔#DFBCB7`; neutrals `#000000 #666666 #A5A5A5 #D9D9D9` | Approved. Formal multi-flow or module palette. Avoid mixing it casually with P1 pastels. |
| P5 | Gray/previous `#666666 #A5A5A5`, burnt-orange/ours `#B34400 #F3BAB1`, plus `#FFFFFF #000000` | Approved non-symmetric previous/ours workflow. Deep anchors for titles; pale tones for large areas. |
| P6 | Signed SDF/UDF diverging: `#053061 #2166AC #4393C3 #92C5DE #D1E5F0 #F7F7F7 #FDDBC7 #F4A582 #D6604D #B2182B #67001F` | Approved continuous blue→neutral→orange-red scale. Do not use as 11 categories. |
| P7 | Flesh `#EDD1C6`, gray `#999999`, green `#B2DEA1` | Approved coordinated equal-weight trio. |
| P8 | Blue `#6F99E1 #C5D5EE` | Candidate. Use only when this softer family fits better than P1/P2. |
| P9 | Red `#E38897 #EDC3C7` | Candidate. |
| P10 | Green `#BFCEA5` | Candidate anchor; do not invent missing family steps. |
| P11 | Mint `#A6E2B4`, coral `#F9856A`, peach `#FACBBB` | Approved geometry/status pairing. Mint and coral are the core pair; peach is a weaker warm layer. |
| P12 | Muted geometry `#DFB5A7 #D2AB9D #90C39C`; gray ramp `#F5F7F9 #E6E6E8 #CDCECF` | Approved low-saturation 3D/geometry palette. Let gray occupy most area. |
| P13 | Violet→coral error ramp: `#251255 #4F127B #752181 #9C2E7F #C53C74 #E95462 #FA7D5E #FEAA74 #FED89A` | Approved continuous error/energy/density scale. |
| P14 | White→orange-red intensity: `#FFFFFF #FEF7F6 #FEEFEE #FDE8E5 #FDE0DC #FCC8B7 #FCAD90 #F67F64 #DE2D26` | Approved sequential scale. Retain borders so low values remain visible on white paper. |
| P15 | Sage `#CACCA2`, muted orange `#D58B53`, steel blue `#7196AC` | Approved coordinated trio. Green/blue may occupy more area; orange works as the accent. |

Standalone utility: table/reference highlight gray `#E6E6E6`.

## Use neutrals as the skeleton

| Role | Recommended values |
|---|---|
| Main text, axes, primary flow | `#000000` |
| Strong structure stroke | `#595959` |
| Secondary labels | `#666666` |
| Auxiliary border/arrow | `#A5A5A5` |
| Baseline objects | `#BFBFC5`, `#D4D4D8` |
| Statistical grid | `#D3D3D3` |
| Weak separators | `#D9D9D9` |
| Table/reference highlight | `#E6E6E6` |
| Card, dark-image border, reversed text | `#FFFFFF` |

Avoid using several nearly identical grays with no role distinction.

## Separate color hierarchy from transparency

- Use fixed light/mid/deep Hex values to encode stable levels in the same family.
- Use alpha for background areas, confidence bands, overlap, shadows, and locator lines.
- A translucent color changes appearance with its background; record both base color and alpha when reproducibility matters.
- For large pale fills, retain grid/border/foreground contrast after export.

## Control area and emphasis

- Most structure should remain black, white, or gray. Use one to three strong semantic colors in an ordinary figure.
- Give saturated warm accents less area than pale or cool supporting regions unless the data require otherwise.
- Use deep colors for labels, borders, or small focal modules; use lighter members for large fills.
- Keep the same semantic object the same color throughout the figure.

## Check text and accessibility

- Choose text color from the local background, including the lightest part of a gradient.
- If contrast fails, first move the label or change the fill. Add a light outline or small translucent backing only as a last step.
- Do not rely on red/green alone. Add labels, line styles, marker shapes, position, or borders and inspect grayscale/color-vision simulations when the distinction is important.
- High-saturation red such as `#FF0000` may be used as a functional ROI/patch annotation token when it is visible across every result image; it is not a categorical palette member and must be applied equally to all methods.

## Add new colors cautiously

Only add a color after:

1. explaining why no existing combination works;
2. defining its role and companion colors;
3. comparing hue, lightness, chroma, and area ratio with the main combination;
4. rendering it at final size on the actual background;
5. recording exact sRGB/alpha and provenance.

