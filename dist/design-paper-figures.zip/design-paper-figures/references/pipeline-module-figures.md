# Pipeline and neural-network figures

Use this reference for algorithm overviews, workflows, method pipelines, mechanism diagrams, network modules, and architecture figures.

## Default to collaboration, not false completeness

When modules, intermediate results, shapes, or connections are incomplete, deliver an editable `Draft / Concept / Wireframe`, not a publication-ready claim.

The first draft must include:

1. a visible reading direction and module layout;
2. real-sized slots for input, important intermediate results, and output;
3. arrows with declared meanings;
4. placeholders such as `[provide: feature map]` or `[confirm: module name]`;
5. a short structure summary and missing-input checklist;
6. a grouped SVG that the user can edit in Figma or another vector tool.

Do not invent algorithm stages, losses, tensor shapes, formulas, feature maps, or outputs to make the diagram look complete.

## Extract the story before the geometry

Separate:

- input and conditioning;
- primary processing stages;
- parallel branches and fusion points;
- repeated or shared modules;
- supervision, teacher, loss, or feedback paths;
- intermediate representations and images;
- training-only versus inference-only elements;
- final outputs.

Choose one dominant topology: left→right, top→bottom, dual-stream merge, encoder–decoder, repeated stages, loop/iteration, or hierarchical tree. Use left→right when the method naturally follows input→processing→output, but do not force it when another topology explains the algorithm more truthfully.

## Audit the layout at two levels

### Macro layout

- Fix single-column or double-column geometry before drawing details.
- Align primary scopes to shared top/bottom anchors when their roles are parallel.
- Keep stable column/row gutters and a clear main spine.
- Place short branches, adapters, conditions, losses, legends, and callouts inside the height envelope created by the main pipeline when possible.
- Share input/output anchors across comparable workflows instead of drawing them twice.

### Dead-space audit

Inspect the entire bounding box. Rework a region when an unused continuous space approaches the size of a meaningful module or result tile and carries no grouping, label, protected-route, or breathing function.

Useful fixes include:

- expanding a real result slot instead of adding prose;
- sharing repeated modules or anchors;
- moving a legend/callout into an existing gap;
- changing direction or column widths;
- nesting a branch above or below the main spine;
- aligning outer scope edges.

Do not maximize raw fill percentage. Internal padding and purposeful gaps remain necessary.

## Encode hierarchy with shape and weight

Use a small visual grammar:

| Role | Preferred treatment |
|---|---|
| Abstract scope, repeated window, optional region | Flat pale rounded container; often dashed |
| Concrete operation/module | Solid rounded card; restrained stroke or fill |
| Important foreground module | Solid card with selective light shadow |
| Input/data/tensor | Image, thumbnail stack, tensor glyph, or neutral card |
| Major intermediate/final result | Replaceable image card with visible border and optional shadow |
| Callout/detail correspondence | Lighter or dashed connector tied to a semantic accent |

- Keep dashed/solid meaning stable. Do not mix line styles for decoration.
- Use roughly three corner-radius levels for small modules, medium cards, and large outer scopes.
- Avoid a heavy black border around every colored module. Fill, placement, and a restrained stroke can establish the boundary.
- Apply shadows to tangible foreground entities, not every nested grouping box.

## Design arrows as a syntax

- Give the primary data flow the strongest consistent directional line.
- Use neutral black/deep gray for the main flow unless multiple semantic flows truly need color.
- Use a semantic accent for conditioning, time, trainable/frozen, or another relationship only when that distinction matters.
- Use dashed/lighter lines for supervision, correspondence, optional paths, or callouts.
- Draw residual and skip connections with short orthogonal or smoothly rounded routes and explicit merge nodes (`+`, concat, gate) when needed.
- Keep arrowheads, width, and corner radius consistent within a relation type. Let the main arrow be visually stronger than ordinary card borders.
- Avoid crossing text and images. Prefer horizontal/vertical segments and rounded corners; restrict long diagonal routes to relationships that need them.

Suggested visual start: primary connectors at roughly `1.3–1.6×` the ordinary module stroke. Judge the final values only after paper-size rendering.

## Use typography by information role

- Prefer a clean humanist sans for dense diagrams. Optima is an aesthetic reference; use an available, embeddable fallback rather than silent substitution.
- Establish three or four levels: major scope/panel title, module label, explanatory label, metadata.
- Fit text to the box while preserving padding. Change wrapping or module width before shrinking labels to illegibility.
- Make tensor shapes, resolutions, token counts, and channel counts smaller/lighter than operation names.
- Use a compatible math font for variables; do not mix many unrelated font families merely to create hierarchy.
- Use italic sparingly for process descriptions or scope captions, not all labels.

## Place images as first-class layout elements

The draft should not be a wall of text boxes.

- Reserve substantial slots for representative inputs, intermediate results, and outputs.
- Keep repeated source frames, views, tokens, or patches compact and usually square inside one shared container.
- Give only important intermediate/final results rounded cards, contrast-aware borders, and light shadows.
- Base border color on the image edge: dark edges often need a near-white border; light edges need a dark/semantic border. Start around `0.8–1.2 pt` and inspect at final size.
- Choose caption color from the local placement region, not the average image brightness. Use short one- or two-line text and move it outside if no safe local region exists.
- For mixed light/dark edges, use a subtle inner stroke plus outer shadow/halo instead of a thick frame.

## Use colors by semantic relationship

Read `color-system.md`. Common choices include:

- P1 for several operator families or stages;
- P2 for two equal paths;
- P4 for multiple formal semantic flows and dark/light entity cards;
- P5 for previous versus proposed workflow;
- P11/P12 for geometry modules or surfaces.

Apply an accent consistently to the related scope caption, important module label, border, and relationship arrow. Keep generic modules and most connectors neutral. Do not color every submodule merely because it belongs to a colored outer group.

Gradients are optional. Use them only to soften large areas, signal direction, or create an entity card; keep endpoints related and verify text contrast across the full gradient.

## Neural-network architecture subtype

In addition to the rules above, show the computational structure accurately.

### Plan repeated structure

- Use `N ×` or another explicit repetition mark rather than redrawing a block many times.
- When expanding one block, align the overview block and detailed block panel with clear correspondence.
- Give parallel variants shared outer dimensions, title baselines, internal padding, and connection entry points.

### Expose tensor evolution

- Show shape/resolution/channel metadata at stable locations using a secondary style.
- Distinguish tensors/tokens from operations using neutral fills or a different glyph.
- Do not fabricate shapes. Mark unknown values as placeholders.

### Show connection semantics

- Distinguish main, residual, skip, conditioning, concat, sum, and gating paths by route and node symbols, not color alone.
- Keep conditioning entry points consistent across repeated blocks.
- Make the main flow and arrowheads stronger than module borders.

### Map operator families consistently

Use color by operation semantics, for example normalization/affine, feed-forward, attention, special attention, and tensor/data. Reduce the number of colors when the architecture has fewer real semantic classes.

## Create a portable grouped SVG

Use stable IDs such as:

```text
scope-input
scope-main
scope-auxiliary
module-encoder
module-core
module-decoder
result-intermediate-01
result-output
connector-primary-01
connector-conditioning-01
placeholder-feature-map
label-scope-main
```

Keep replacement images, clipping paths, captions, and borders in the same logical group, but keep connectors independent. Use relative asset paths or embed small placeholders; never preserve absolute paths from the authoring machine.

## Checklist

- The main story is readable without following every small label.
- The target column geometry and outer anchors were fixed before local decoration.
- No protrusion or misalignment creates a large dead zone.
- Input, meaningful intermediate results, and output have real image area.
- Dashed/solid lines, colors, arrows, shadows, and rounded corners each have stable semantics.
- Local text and image borders pass contrast checks.
- Architecture shapes and connections are supplied or visibly marked unknown.
- The SVG has named groups and replaceable slots; PNG is only a preview.
- The draft is explicitly labeled and accompanied by a missing-input checklist.

