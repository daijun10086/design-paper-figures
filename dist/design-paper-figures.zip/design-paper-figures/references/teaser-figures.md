# Teaser figures

A teaser is the paper's first visual argument. Its first job is to let a reader understand what the paper does and why it matters within a few seconds. Treat it as high-freedom art direction, not a fixed diagram template.

## Begin with one sentence

Write the sentence a reader should be able to repeat after scanning the teaser. Keep only visual evidence that supports it.

Check whether the visual answers the most important two or three questions:

- What is the input or problem?
- What does the method do?
- What capability, quality, efficiency, or insight is new?

Do not summarize every module, loss, dataset, and ablation.

## Select the evidence mode

### 1. Capability showcase

Use when the task or capability is new and meaningful baselines are scarce. Show what the method can do through diverse, representative input/output pairs, controllable dimensions, sequences, or applications.

An effective structure may progress from a low-cost direct mapping to a stronger property such as continuous control, generalization, editing range, or temporal consistency.

### 2. Comparative proof

Use when the task is mature and the main claim is better quality, speed, compression, or resource efficiency.

- Give baseline and proposed methods the same crop, size, evidence stack, metric definition, and visual treatment.
- Use isomorphic columns so the reader learns one repeated grammar.
- Combine complementary evidence such as reconstruction, a shared-range error map, one quality metric, and one cost metric.
- A large proposed/context image is justified only if it supplies scene context or a clear ROI source; it must not make baseline evidence too small.

### 3. Intuition plus results

Use when outputs alone do not reveal the novelty but the central representation or physical/geometric idea can be explained as one short visual sentence.

- Put one minimal intuition/mechanism above or beside the results.
- Show outputs that directly close the loop with that intuition.
- Keep full architecture, training, and losses in the method figure.

### Hybrid

A hero result plus a compact comparison strip can combine capability and proof, but choose one dominant narrative. Do not let two equal stories compete for attention.

## Design the layout around evidence bands

- Different bands may use different local grids if they serve different narrative functions.
- Lock every band to a common outer width or other deliberate shared anchor.
- Satisfy `sum(tile widths) + sum(gutters) + label rails = common content width` without distorting images.
- Use text, separators, and arrows inside narrow inter-band spaces so gaps perform grouping or explanation.
- Audit side rails and spanning inputs. If a single short input leaves empty space across multiple bands, add a scientifically useful condition/input, let an image span the bands, or restructure the rail. Do not add unrelated decoration.
- Keep all captions and metrics on explicit shared baselines. If one column has fewer lines, use a common caption band and optical centering rather than top-aligning sparse text.

## Select cases for science and visual rhythm

First create a semantic coverage matrix based on the paper claims: task types, object categories, materials, backgrounds, difficulty, geometry, viewpoints, or control ranges.

Then choose among scientifically valid candidates to avoid a visually homogeneous wall:

- vary dominant hue and brightness;
- vary silhouette, scene type, and texture;
- avoid adjacent cases that are all white, black, or on the same background;
- keep representative hard cases and do not hide failure modes solely for visual polish.

Never recolor, fabricate, or selectively process model outputs to create a nicer palette.

## Use text and connectors sparingly

- Keep teaser labels short and scannable; move detailed explanation to the official caption.
- Use thin separators to establish attribute or case groups, and arrows only when they express a control direction or mapping.
- Use ROI boxes and two connectors when a local comparison needs the context of a hero image.
- Error maps must share reference, alignment, definition, range, scaling, and colormap. Disclose any display multiplier.

## Choose typography and color

- Use a clean academic font stack coordinated with the paper. A SIGGRAPH/ACM-like restrained typographic hierarchy is a preferred aesthetic direction, not a venue restriction.
- Read `color-system.md` and choose a coherent combination. Do not copy an unattractive or inaccessible red/green scheme merely because a reference used it.
- Let color support the narrative and grouping; do not use a different accent for every case.
- Test local text contrast, especially on large images and gradients.

## Collaborate in stages

When real assets or narrative decisions are incomplete, return:

1. the selected evidence mode and one-sentence claim;
2. one primary concept and, only if genuinely different, one alternative;
3. a compact editable layout sketch with reading order;
4. clearly sized real-result placeholders;
5. an asset checklist and the few decisions that would materially change the layout.

Do not call the sketch a final teaser. Once the user supplies and confirms results, help with crop, alignment, captions, color, and export while retaining editable source elements.

## Checklist

- A reader can state the paper's main claim after a quick scan.
- The evidence mode matches task maturity and the strongest claim.
- Intuition, results, comparisons, metrics, and hero images each have a clear job.
- Different content bands share deliberate outer anchors and contain no dead side rails.
- Cases satisfy scientific coverage before aesthetic variety.
- Comparisons and error maps are fair and identically processed.
- Text, separators, arrows, and gaps contribute information rather than decoration.
- The concept remains editable and uses real supplied scientific outputs.

