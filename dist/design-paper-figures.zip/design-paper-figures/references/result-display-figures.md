# Qualitative result-display figures

Use this reference for generation samples, reconstruction, NVS/neural rendering, 3D point clouds, meshes, geometry, depth, normals, and baseline comparisons.

## Audit the modality first

Different modalities require different fairness controls.

- **2D image / NVS / rendering:** keep crop, aspect ratio, resolution, color space, view, and post-processing consistent.
- **Point cloud:** keep camera pose, projection, axis range, point size, background, and frustum consistent.
- **Mesh / geometry:** keep viewpoint, lighting, material, scale, coordinate convention, and background consistent.
- **Depth / normal / scalar fields:** keep range, convention, colormap, normalization, and colorbar consistent.
- **Mixed modality:** separate into panels and make correspondence explicit rather than treating unlike observations as identical tiles.

Never create model results or ground truth to fill a layout.

## Define row and column semantics

State what rows and columns encode: method, case, scene, dataset, view, time, seed, scale, ablation, or input type.

- Use a normal `case × method` matrix when there are two dimensions.
- Use nested mini-grids only when a real third variable exists.
- Use a mosaic with integer cell spans for representative displays of different importance or resolution. Do not use unequal area for a fair method comparison.
- Repeated variables should be labeled once through shared headers, side labels, or direction arrows.

## Calculate tile size before choosing the grid

Start from the actual single/double-column width. Estimate:

```text
tile_width = (available_width - label_rails - dividers - all_gutters) / columns
```

Render a candidate at paper size. If the subject, texture, patch, or caption becomes hard to read, reduce the number of images per row. Use additional rows, nested `2 × n` blocks, separate input columns, stacked cases, or multiple panels.

Do not confuse compactness with putting every image in one row. The correct layout preserves useful tile size and then eliminates meaningless empty space.

Use `../scripts/plan_result_grid.py` for quick feasibility estimates.

## Align strictly

- Derive tile sizes, row heights, column centers, headers, gutters, and dividers from one grid.
- Keep left/right boundaries and each row's total width aligned.
- Preserve image aspect ratios. Apply the same crop rule within a comparison group.
- Use integer pixel tile/gutter values when assembling raster contact sheets, then scale the whole layout to paper size.
- Re-render after composition to catch cumulative drift.

## Choose gutters, borders, and dividers by function

### Gutters

- Zero gutter is an optional style when image boundaries are already clear.
- Use a consistent gutter when adjacent images would merge or when methods/views need separation.
- Define a base gutter `g`; use a clear multiple such as `2g–4g` for a higher-level group gap rather than tuning every space independently.

### Borders

- Test a black/near-black image border around `0.8–1.0 pt` at final size.
- Use a near-white border or a pale group backing when images are predominantly dark.
- Prevent adjacent tile borders from stacking into a double-width seam.

### Dividers

- Use a restrained solid line to separate reference/input/ground-truth from prediction methods.
- Use a different, possibly dashed, separator for case groups or another hierarchy.
- Let separators span the intended group and align with the grid. Do not draw a line between every method.

## Build headers economically

- Align method labels to the exact tile centers and a shared baseline.
- Use a two-level header when columns share a variable: a global variable/direction layer plus per-column values.
- Use a narrow side label rail for long case/dataset names. Rotate text only when it materially improves the bounding box and remains readable at final size.
- When a nested layout changes the method in each tile, attach concise per-tile headers rather than pretending the column meaning is constant.
- Put a small metric inside each tile at a fixed location only when it does not hide evidence. Otherwise use a shared header or caption strip.

## Design image magnification patches fairly

An image patch component consists of a small ROI, two connectors, and a larger inset.

1. Choose one scientifically meaningful ROI in the ground truth/reference or common view.
2. Lock normalized ROI coordinates, scale, inset size, border style, and inset anchor across all methods in that case.
3. Use two non-crossing connectors from neighboring ROI corners to matching inset corners, forming a clear trapezoid/perspective expansion.
4. Keep `ROI < connector < inset border` in visual weight. A useful starting ratio is `1:2:4`, adjusted so the small ROI remains visible.
5. Use one high-contrast functional annotation color across the entire figure. Bright red can work, but test it against every case and use a fine halo if required.
6. Select the inset corner by avoiding subjects, faces, text, key geometry, and the ROI. Lock that anchor across methods in the same row/case.
7. If all internal positions obscure important content, place patches in a shared external zoom row/column.

Do not optimize ROI or anchor independently for each method. Do not give the proposed method a stronger annotation style.

## Select cases honestly and visually

- Include representative cases, relevant hard cases, and sufficient dataset/task coverage.
- Among equally valid candidates, arrange cases to vary dominant hue, brightness, background, subject type, and geometry.
- Avoid an entire row/page of visually identical white, black, or same-background results.
- Do not recolor results or remove failures for appearance.

## Draft before compositing

With incomplete assets, create an editable grid showing:

- real row/column counts and variable meanings;
- target paper width and estimated tile size;
- input/GT/method dividers;
- headers and case rails;
- image placeholders;
- ROI and protected-region placeholders;
- candidate patch anchors;
- missing matched views/results.

After assets arrive, verify filenames, dimensions, view correspondence, crop, and color-space consistency before assembling.

## Export

- Keep labels, borders, dividers, ROI boxes, and connectors vector when possible.
- Embed images without unnecessary recompression. Use lossless PNG for synthetic/depth/normal data and sufficiently high-quality encoding for photographs/renders.
- Deliver editable SVG/PPT layout plus paper-ready PDF and a high-resolution PNG preview.

## Checklist

- Modality-specific view/range/color conventions are consistent.
- Rows, columns, nested grids, and labels represent real variables.
- Candidate grid was tested at final paper width and every tile remains useful.
- Tile boundaries, gutters, borders, headers, and dividers align exactly.
- Comparisons use identical crop, size, and processing.
- Patches use matched ROI, two connectors, hierarchy of line weights, and subject-aware anchors.
- Case selection balances coverage, difficulty, and visual variety.
- The bounding box is compact without sacrificing tile readability.
- Editable layout and high-quality exports are included.

