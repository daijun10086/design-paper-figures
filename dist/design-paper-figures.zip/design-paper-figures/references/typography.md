# Typography for paper figures

Use one coherent family per figure unless a mathematically necessary companion
font is required. Choose typography by role and final-size readability, not by
whatever font Matplotlib happens to find first.

## Use the validated preference tiers

| Tier | Font/profile | Use |
|---|---|---|
| Primary default | Optima / `preferred` or `optima` | First choice for statistical figures when installed and exportable; refined humanist character with a strong Graphics-paper feel. |
| High-priority expressive | Futura / `futura` | Strongly preferred for compact plots with short labels and uncluttered legends. Inspect small ticks carefully because its geometric construction is less forgiving in dense charts. |
| High-priority humanist | Gill Sans / `gill-sans` | Distinctive alternative when Optima is unavailable or a slightly more informal humanist voice fits. |
| Approved neutral | DejaVu Sans / `seaborn`; Helvetica Neue / `helvetica-neue`; Avenir / `avenir` | Use when the plot needs a quieter or more conventional voice. DejaVu Sans is the most portable and is usually the effective Matplotlib/Seaborn default. |
| Conservative fallback | Arial / `conservative` | Keep available, but do not select first. Use after the preferred candidates are unavailable or rejected, or when compatibility requires a conventional Arial-led stack. |

Candidate C in the validated comparison is Optima; treat the repeated approval
of “Optima” and “Candidate C” as strong evidence for the same primary family.
Candidate F is Gill Sans and Candidate G is Futura.

## Do not reduce the policy to one fallback string

The default Matplotlib style uses this robust automatic stack:

```text
Optima → Gill Sans → Helvetica Neue → Helvetica → Avenir → DejaVu Sans → Arial
```

Futura is intentionally not an automatic fallback. Select the `futura` profile
explicitly so the agent must check whether short labels, tick density, legend
width, and target paper size suit its display-oriented geometry.

Use the helper to make the choice explicit and reproducible:

```python
from paper_plot_style import use_style

resolved_family = use_style("preferred")  # usually Optima on a compatible Mac
# resolved_family = use_style("futura")
# resolved_family = use_style("gill-sans")
# resolved_family = use_style("seaborn")
# resolved_family = use_style("conservative")
```

Record `resolved_family` when reproducibility across a laptop and server
matters. Never describe a plot as Optima if the renderer substituted another
font.

## Calibrate size and weight optically

- Render at the intended single- or double-column width. The same numeric point
  size can look substantially smaller, wider, lighter, or heavier across these
  families.
- Start near 8 pt for axis labels, 7 pt for ticks/legends, and 9 pt for titles,
  then adjust by apparent size rather than copying point values mechanically.
- Use regular weight for most labels. Reserve bold for a short title, proposed
  method, or explicit visual conclusion, and confirm the selected family has a
  real bold face rather than synthetic emboldening.
- Check long legend entries and capitalized acronyms. Futura often needs more
  width; Optima may need slightly larger small text; DejaVu Sans appears denser
  at the same point size.

## Coordinate symbols, math, and export

- Audit arrows, Greek letters, subscripts, and mathematical operators. Some
  system fonts lack individual Unicode glyphs even when ordinary Latin text is
  complete.
- Use a compatible math companion when the figure contains substantial math;
  do not allow a visibly unrelated default math font to appear silently.
- Export PDF with TrueType embedding and SVG with live text, then inspect font
  declarations and a rasterized preview for substitution or missing glyphs.
- Do not package proprietary Apple or Microsoft font files in the portable
  Skill. Reference installed family names and retain DejaVu Sans as the
  embeddable server-safe fallback.

## Compare before changing the default again

When revising typography, render one representative statistical plot with
identical data, geometry, palette, line weights, ticks, and annotations. Change
only the font family, inspect every candidate at actual size, and update the
profile order only after user review.
