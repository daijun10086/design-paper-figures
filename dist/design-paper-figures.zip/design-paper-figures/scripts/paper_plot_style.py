#!/usr/bin/env python3
"""Portable helpers for publication-oriented Matplotlib figures.

The module intentionally provides styling primitives rather than a fixed chart
template. Import it from a plotting script, or run its CLI to inspect the
bundled palette and generate a small smoke-test figure.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable, Sequence


SKILL_DIR = Path(__file__).resolve().parents[1]
ASSET_DIR = SKILL_DIR / "assets"
COLOR_BANK_PATH = ASSET_DIR / "color-bank.json"
MPLSTYLE_PATH = ASSET_DIR / "paper-figure.mplstyle"


def load_color_bank() -> dict:
    """Load and minimally validate the machine-readable color bank."""
    data = json.loads(COLOR_BANK_PATH.read_text(encoding="utf-8"))
    colors = data.get("colors", [])
    combinations = data.get("combinations", [])
    ids = [color["id"] for color in colors]
    hexes = [color["hex"].upper() for color in colors]
    if len(ids) != len(set(ids)):
        raise ValueError("Color bank contains duplicate color ids")
    if len(hexes) != len(set(hexes)):
        raise ValueError("Color bank contains duplicate canonical Hex values")
    known = set(ids)
    for combination in combinations:
        unknown = set(combination["member_color_ids"]) - known
        if unknown:
            raise ValueError(
                f"Combination {combination['id']} references unknown colors: {sorted(unknown)}"
            )
    return data


def get_combination(combination_id: str) -> dict:
    """Return a combination with its full color records attached."""
    data = load_color_bank()
    by_id = {color["id"]: color for color in data["colors"]}
    for combination in data["combinations"]:
        if combination["id"] == combination_id:
            result = dict(combination)
            result["colors"] = [by_id[color_id] for color_id in combination["member_color_ids"]]
            return result
    choices = ", ".join(item["id"] for item in data["combinations"])
    raise KeyError(f"Unknown combination {combination_id!r}. Available: {choices}")


def combination_hexes(combination_id: str) -> list[str]:
    """Return ordered Hex values for a stored combination."""
    return [color["hex"] for color in get_combination(combination_id)["colors"]]


def use_style() -> None:
    """Activate the bundled Matplotlib style for the current process."""
    import matplotlib.pyplot as plt

    plt.style.use(MPLSTYLE_PATH)


def style_axes(
    ax,
    *,
    grid: bool | str = True,
    full_frame: bool = True,
    spine_width: float = 0.8,
    grid_color: str = "#D3D3D3",
    grid_width: float = 0.5,
) -> None:
    """Apply the learned statistical-figure skeleton to one axes.

    ``grid`` may be ``True``/``False`` or ``"x"``/``"y"``. Treat it as a
    deliberate readability choice rather than a decoration requirement.
    """
    ax.set_axisbelow(True)
    for side, spine in ax.spines.items():
        spine.set_visible(full_frame or side in {"left", "bottom"})
        spine.set_linewidth(spine_width)
        spine.set_color("#000000")
    ax.tick_params(width=spine_width, colors="#202124")
    if grid is False:
        ax.grid(False)
    else:
        axis = "both" if grid is True else str(grid)
        if axis not in {"both", "x", "y"}:
            raise ValueError("grid must be True, False, 'x', or 'y'")
        ax.grid(True, axis=axis, color=grid_color, linewidth=grid_width, alpha=1.0)


def add_zoomed_inset(
    ax,
    *,
    bounds: Sequence[float],
    xlim: Sequence[float],
    ylim: Sequence[float],
    connector_locs: tuple[int, int] = (2, 4),
    locator_color: str = "#595959",
    locator_width: float = 1.0,
    locator_alpha: float = 0.5,
    grid: bool | str = True,
):
    """Create an inset axes and draw its ROI/connectors on the parent axes.

    Parameters
    ----------
    bounds:
        ``(left, bottom, width, height)`` in parent-axes coordinates.
    xlim, ylim:
        Data limits for the magnified region.
    connector_locs:
        Corner codes accepted by ``mpl_toolkits.axes_grid1.mark_inset``.

    Plot the same relevant artists into the returned axes, then set sparse
    ticks explicitly. The helper does not copy artists automatically.
    """
    from mpl_toolkits.axes_grid1.inset_locator import mark_inset

    if len(bounds) != 4:
        raise ValueError("bounds must contain left, bottom, width, and height")
    inset = ax.inset_axes(bounds)
    inset.set_xlim(*xlim)
    inset.set_ylim(*ylim)
    style_axes(inset, grid=grid, full_frame=True)
    mark_inset(
        ax,
        inset,
        loc1=connector_locs[0],
        loc2=connector_locs[1],
        fc="none",
        ec=locator_color,
        lw=locator_width,
        alpha=locator_alpha,
    )
    return inset


def export_figure(
    fig,
    output_stem: str | Path,
    *,
    formats: Iterable[str] = ("pdf", "svg", "png"),
    dpi: int = 300,
) -> list[Path]:
    """Export vector masters plus a high-resolution PNG preview."""
    stem = Path(output_stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for fmt in formats:
        normalized = fmt.lower().lstrip(".")
        path = stem.with_suffix(f".{normalized}")
        kwargs = {"bbox_inches": "tight", "pad_inches": 0.03}
        if normalized == "png":
            kwargs["dpi"] = dpi
        fig.savefig(path, **kwargs)
        written.append(path)
    return written


def _demo(output_dir: Path) -> list[Path]:
    import numpy as np
    import matplotlib.pyplot as plt

    use_style()
    palette = get_combination("p1-soft-scientific-five-hue")
    by_id = {color["id"]: color["hex"] for color in palette["colors"]}
    series = [
        ("Method A", "soft-orange-deep", 0.0),
        ("Method B", "soft-grass-deep", 0.18),
        ("Method C", "soft-coral-deep", 0.34),
        ("Proposed", "soft-blue-deep", 0.52),
    ]
    x = np.linspace(0, 1000, 240)
    fig, ax = plt.subplots(figsize=(6.7, 3.0))
    for index, (label, color_id, offset) in enumerate(series):
        y = 2.0 + 8.5 * np.exp(-x / (180 + 25 * index)) + offset
        y += 0.035 * np.sin(x / (34 + 2 * index))
        ax.plot(x, y, color=by_id[color_id], label=label, marker="o", markevery=35)
    style_axes(ax, grid=True)
    ax.set_xlabel("Training steps")
    ax.set_ylabel("Validation error ↓")
    ax.legend(ncol=2, loc="upper right")

    inset = add_zoomed_inset(
        ax,
        bounds=(0.54, 0.20, 0.40, 0.40),
        xlim=(650, 1000),
        ylim=(2.35, 3.35),
        connector_locs=(2, 4),
    )
    for index, (_, color_id, offset) in enumerate(series):
        y = 2.0 + 8.5 * np.exp(-x / (180 + 25 * index)) + offset
        y += 0.035 * np.sin(x / (34 + 2 * index))
        inset.plot(x, y, color=by_id[color_id], marker="o", markevery=35, linewidth=1.2)
    inset.set_xticks([700, 850, 1000])
    inset.set_yticks([2.4, 2.8, 3.2])
    inset.tick_params(labelsize=6)
    fig.tight_layout()
    paths = export_figure(fig, output_dir / "paper-plot-style-demo")
    plt.close(fig)
    return paths


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--list-combinations", action="store_true")
    action.add_argument("--show-combination", metavar="ID")
    action.add_argument("--demo", metavar="OUTPUT_DIR", type=Path)
    return parser


def main() -> int:
    args = _build_parser().parse_args()
    if args.list_combinations:
        for item in load_color_bank()["combinations"]:
            print(f"{item['id']}\t{item['status']}\t{item['name']}")
        return 0
    if args.show_combination:
        print(json.dumps(get_combination(args.show_combination), indent=2, ensure_ascii=False))
        return 0
    written = _demo(args.demo)
    for path in written:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

