#!/usr/bin/env python3
"""Estimate paper-size tile dimensions for qualitative result grids.

This is a feasibility calculator, not an automatic layout designer. Review the
scientific grouping and actual rendered images before choosing a candidate.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass


POINTS_PER_INCH = 72.0


@dataclass(frozen=True)
class Candidate:
    columns: int
    rows_per_case: int
    total_rows: int
    empty_slots_per_case: int
    tile_width_pt: float
    tile_width_in: float
    tile_height_pt: float
    tile_height_in: float
    estimated_height_pt: float
    estimated_height_in: float
    readable_width: bool
    within_max_height: bool | None


def calculate_candidates(
    *,
    items_per_case: int,
    cases: int,
    target_width_in: float,
    aspect_ratio: float,
    gutter_pt: float,
    case_gap_pt: float,
    label_rail_pt: float,
    divider_allowance_pt: float,
    header_pt: float,
    min_tile_width_pt: float,
    min_columns: int,
    max_columns: int,
    max_height_in: float | None,
) -> list[Candidate]:
    if items_per_case < 1 or cases < 1:
        raise ValueError("items_per_case and cases must be positive")
    if target_width_in <= 0 or aspect_ratio <= 0:
        raise ValueError("target width and aspect ratio must be positive")
    if min_columns < 1 or max_columns < min_columns:
        raise ValueError("invalid column range")

    target_width_pt = target_width_in * POINTS_PER_INCH
    results: list[Candidate] = []
    for columns in range(min_columns, min(max_columns, items_per_case) + 1):
        available = (
            target_width_pt
            - label_rail_pt
            - divider_allowance_pt
            - gutter_pt * (columns - 1)
        )
        if available <= 0:
            continue
        tile_width = available / columns
        tile_height = tile_width / aspect_ratio
        rows_per_case = math.ceil(items_per_case / columns)
        total_rows = rows_per_case * cases
        empty_slots = rows_per_case * columns - items_per_case
        row_gaps = gutter_pt * max(0, total_rows - cases)
        group_gaps = case_gap_pt * max(0, cases - 1)
        estimated_height = header_pt + total_rows * tile_height + row_gaps + group_gaps
        within_height = (
            None
            if max_height_in is None
            else estimated_height <= max_height_in * POINTS_PER_INCH
        )
        results.append(
            Candidate(
                columns=columns,
                rows_per_case=rows_per_case,
                total_rows=total_rows,
                empty_slots_per_case=empty_slots,
                tile_width_pt=round(tile_width, 2),
                tile_width_in=round(tile_width / POINTS_PER_INCH, 3),
                tile_height_pt=round(tile_height, 2),
                tile_height_in=round(tile_height / POINTS_PER_INCH, 3),
                estimated_height_pt=round(estimated_height, 2),
                estimated_height_in=round(estimated_height / POINTS_PER_INCH, 3),
                readable_width=tile_width >= min_tile_width_pt,
                within_max_height=within_height,
            )
        )
    return results


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--items-per-case", type=int, required=True)
    parser.add_argument("--cases", type=int, default=1)
    parser.add_argument("--target-width-in", type=float, required=True)
    parser.add_argument(
        "--aspect-ratio",
        type=float,
        default=1.0,
        help="tile width / tile height; default 1.0 for square tiles",
    )
    parser.add_argument("--gutter-pt", type=float, default=4.0)
    parser.add_argument("--case-gap-pt", type=float, default=10.0)
    parser.add_argument("--label-rail-pt", type=float, default=0.0)
    parser.add_argument("--divider-allowance-pt", type=float, default=1.0)
    parser.add_argument("--header-pt", type=float, default=18.0)
    parser.add_argument("--min-tile-width-pt", type=float, default=72.0)
    parser.add_argument("--min-columns", type=int, default=1)
    parser.add_argument("--max-columns", type=int, default=8)
    parser.add_argument("--max-height-in", type=float)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def main() -> int:
    args = _parser().parse_args()
    candidates = calculate_candidates(
        items_per_case=args.items_per_case,
        cases=args.cases,
        target_width_in=args.target_width_in,
        aspect_ratio=args.aspect_ratio,
        gutter_pt=args.gutter_pt,
        case_gap_pt=args.case_gap_pt,
        label_rail_pt=args.label_rail_pt,
        divider_allowance_pt=args.divider_allowance_pt,
        header_pt=args.header_pt,
        min_tile_width_pt=args.min_tile_width_pt,
        min_columns=args.min_columns,
        max_columns=args.max_columns,
        max_height_in=args.max_height_in,
    )
    if args.as_json:
        print(json.dumps([asdict(item) for item in candidates], indent=2))
        return 0

    print(
        "cols  rows/case  total rows  empty/case  tile width  tile height  est. height  readable  height-ok"
    )
    for item in candidates:
        height_ok = "n/a" if item.within_max_height is None else ("yes" if item.within_max_height else "no")
        print(
            f"{item.columns:>4}  {item.rows_per_case:>9}  {item.total_rows:>10}  "
            f"{item.empty_slots_per_case:>10}  {item.tile_width_pt:>7.1f} pt  "
            f"{item.tile_height_pt:>7.1f} pt  {item.estimated_height_in:>8.2f} in  "
            f"{'yes' if item.readable_width else 'no ':>8}  {height_ok:>9}"
        )
    print()
    print(
        "Interpretation: reject candidates whose tiles are unreadable at the final paper width; "
        "then compare grouping, empty slots, total height, labels, patches, and scientific semantics."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

