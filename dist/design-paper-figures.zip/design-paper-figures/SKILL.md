---
name: design-paper-figures
description: Design, redraw, restyle, review, or assemble publication-quality figures for academic papers. Use for statistical plots and tables; algorithm pipelines and method overviews; neural-network module or architecture diagrams; teaser/first-page figures; qualitative result displays for generation, reconstruction, NVS, rendering, point clouds, meshes, depth, normals, or geometry; and academic color-palette selection. Trigger whenever a user asks Codex to draw, improve, plan, or evaluate a research-paper figure, including Python/Matplotlib charts. Produce editable drafts for information-incomplete diagrams and honest, reproducible final figures when data and source assets are available.
---

# Design Paper Figures

Create figures that are scientifically honest, visually disciplined, compact at the target paper size, and easy for the researcher to continue editing.

## Route the figure before drawing

Classify the request by the figure's primary job. Read only the matching reference, plus the color reference.

| Figure job | Read | Default delivery |
|---|---|---|
| Statistical evidence: curves, bars, scatter, distributions, heatmaps, tables, multi-panel plots | `references/statistical-figures.md` | Publication-quality source + PDF/SVG + PNG |
| Algorithm pipeline, method overview, workflow, or mechanism | `references/pipeline-module-figures.md` | Editable SVG draft with named groups + PNG preview |
| Neural-network module or architecture | `references/pipeline-module-figures.md`, architecture section | Editable SVG draft; expose shapes and connections for correction |
| Teaser / first-page figure | `references/teaser-figures.md` | One or two concepts, then an editable layout draft |
| Qualitative result display or baseline comparison | `references/result-display-figures.md` | Editable layout first; composite only from real supplied results |
| Palette selection, restyling, or color review | `references/color-system.md` | Use an existing combination unless a new one is justified |

For mixed figures, identify one dominant job and use the other references only for the relevant component. Do not apply statistical axes to a result grid or expand a teaser into a full method diagram.

## Follow the core workflow

1. **Extract the scientific sentence.** State what the reader should understand after three to five seconds. Preserve the distinction between facts supplied by the user, reasonable layout assumptions, and missing content.
2. **Fix the target geometry.** Determine single-column, double-column, full-page, slide, or web width before choosing a grid. Estimate the final physical size of text, tiles, lines, patches, and arrowheads.
3. **Inventory the evidence.** Identify data, source images, intermediate results, baselines, ground truth, labels, metrics, tensor shapes, and formulas. Never invent experimental outputs, algorithm stages, losses, shapes, or values.
4. **Choose the information structure.** Define the reading direction, row/column semantics, grouping, hierarchy, and shared anchors before styling individual objects.
5. **Select one color combination by relationship.** Read `references/color-system.md`. Use hue for independent categories, fixed light/mid/deep colors for hierarchy, alpha for overlap or background regions, and neutrals for most structure.
6. **Create the right maturity level.** Statistical plots can be final when the data are complete. Pipelines, architecture diagrams, teasers, and result layouts should remain clearly labeled drafts until real intermediate results and user decisions are available.
7. **Render at actual paper size.** Inspect the exported output rather than trusting the authoring canvas. Check dead space, alignment, clipping, font substitution, contrast, overlaps, connector routing, and whether details remain readable.
8. **Deliver editable sources.** Keep text, arrows, borders, labels, and replacement slots vector-editable. Include a preview, but never make PNG the only deliverable for a diagram or layout draft.

## Apply these global design rules

### Protect scientific truth

- Keep matched methods under identical crop, scale, view, dynamic range, post-processing, and annotation rules.
- Do not use layout, area, font size, error-map scaling, or patch placement to unfairly favor the proposed method.
- Suggest visually diverse cases only after scientific coverage and representativeness are satisfied.
- Label assumptions and placeholders. Do not fill empty space with fabricated content.

### Treat compactness as useful occupancy

- Make the bounding box orderly and well used; do not force every figure into a rectangle for its own sake.
- Remove dead space caused by misaligned outer scopes, isolated legends, unnecessary protrusions, repeated anchors, or a grid that is too wide for the target column.
- Preserve purposeful breathing room, padding, grouping gaps, and protected regions. Compact does not mean zero spacing.
- Prefer shared top/bottom anchors, consistent gutters, integer grid spans, and reusable alignment tokens over per-object dragging.

### Build a restrained hierarchy

- Use one coherent font family with a small number of sizes and weights. Let labels, metadata, captions, tensor shapes, and mathematical symbols have distinct but related roles.
- Use rounded rectangles for modules when appropriate, not for every image or tensor. Use solid/dashed borders only when the line style has a stable meaning.
- Apply light shadows to foreground entities or important result cards; keep abstract scopes and grouping boxes flat.
- Make arrows more directional than ordinary borders. Route primary flows cleanly and give secondary, conditioning, residual, supervision, or callout paths distinct but consistent syntax.
- Choose text and image borders from the local background: dark-on-light, light-on-dark. Move labels before adding heavy outlines or opaque banners.

## Use portable typography

- Prefer installed, embeddable fonts. For statistical plots, start with Arial, Helvetica, Liberation Sans, or DejaVu Sans.
- For pipelines and teasers, a humanist sans such as Optima is an aesthetic reference; portable fallbacks include Candara, Segoe UI, Noto Sans, Liberation Sans, and DejaVu Sans.
- Coordinate math with the main font. Do not depend on a proprietary font without checking availability and export embedding.
- If the paper template requires serif typography, follow it consistently rather than mixing unrelated figure fonts.

## Preserve editability

For SVG diagrams, create named groups such as:

```text
figure
├── scopes
├── connectors
│   ├── primary-flow
│   └── auxiliary-flow
├── input
├── modules
├── intermediate-results
├── output
├── labels
└── notes-and-placeholders
```

Give every replaceable image its own group and clipping path. Keep connectors separate from cards so users can move modules and reconnect them in Figma, Illustrator, Inkscape, or another vector editor. Use PPTX only when requested or when that is the user's main editing environment.

## Use the bundled resources

- Read `references/color-system.md` before selecting colors. Exact machine-readable values are in `assets/color-bank.json`; the overview is `assets/master-color-bank-palette.svg`.
- For Matplotlib, import `scripts/paper_plot_style.py` or apply `assets/paper-figure.mplstyle`. The helper supplies frame, grid, palette, zoom-inset, and export primitives without fixing the data or layout.
- Before laying out a large result comparison, run `scripts/plan_result_grid.py` to estimate tile size for candidate column counts. Treat its result as a feasibility check, not an automatic design decision.
- Start editable pipeline brainstorming from `assets/pipeline-wireframe-template.svg` only when its left-to-right structure fits the method. Rearrange or discard it when the story requires another topology.

## Deliver by figure type

### Statistical figures

Return the source code and vector output. Also provide a high-resolution PNG for quick inspection. State scale choices, manual ticks, alpha usage, and any inset limits when these decisions affect interpretation.

### Pipeline and architecture figures

Return an explicitly marked `Draft`, `Concept`, or `Wireframe`, a short structure summary, a list of missing assets or decisions, and an editable grouped SVG. Reserve real area for inputs, intermediate images, and outputs; do not return a wall of text boxes.

### Teasers

Return the proposed evidence mode, reading sequence, visual hierarchy, layout sketch, and asset checklist. Do not claim a final teaser until the user has confirmed the narrative and supplied real results.

### Result displays

Return the target grid semantics and estimated tile size before assembling. With real assets, preserve aspect ratios and comparable conditions, then deliver an editable layout plus paper-ready PDF/PNG. Never substitute generated images for model outputs or ground truth.

## Complete the final audit

- Can a reader state the main message within a few seconds?
- Is every strong visual choice tied to scientific meaning or reading order?
- Does the figure fit its actual column/page width without unreadably small text, tiles, or patches?
- Are outer anchors, row/column centers, gutters, headers, dividers, captions, and connector routes aligned?
- Is there dead space close to the size of a meaningful module or tile? If so, redesign rather than decorate it.
- Are colors drawn from a coherent combination, with redundant shape/line/label cues where needed?
- Are all comparisons fair and all assumptions visible?
- Is the editable source included, and has the exported output been visually inspected?

